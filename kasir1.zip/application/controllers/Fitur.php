<?php

use Dompdf\Dompdf;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Fitur extends CI_Controller {
	public function __construct(){
		parent::__construct();
		if($this->session->login['role'] != 'kasir' && $this->session->login['role'] != 'admin') redirect();
		date_default_timezone_set('Asia/Jakarta');
		$this->load->model('M_barang', 'm_barang');
		$this->load->model('M_fitur', 'm_fitur');
		$this->load->model('m_detail_fitur', 'm_detail_fitur');
		$this->data['aktif'] = 'fitur';
	}

	public function index(){
		redirect('fitur/lihat_pemakaian');
	}
	//pemakaian
	public function lihat_pemakaian(){
		$this->data['title'] = 'Data Pemakaian';
		$this->data['all_pemakaian'] = $this->m_fitur->lihat_pemakaian();

		$this->load->view('fitur/lihat_pemakaian', $this->data);
	}
	public function tambah_pemakaian(){
		$this->data['title'] = 'Tambah Pemakaian';
		$this->load->view('fitur/tambah_pemakaian', $this->data);
	}
	public function detail_pemakaian($no_pemakaian){
		$this->data['title'] = 'Detail Pemakaian';
		$this->data['pemakaian'] = $this->m_fitur->lihat_no_pemakaian($no_pemakaian);
		$this->data['all_detail_pemakaian'] = $this->m_detail_fitur->lihat_no_pemakaian($no_pemakaian);
		$this->data['no'] = 1;

		$this->load->view('fitur/detail_pemakaian', $this->data);
	}
	public function proses_tambah(){
		$jumlah_barang_pemakaian = count($this->input->post('nama_barang_hidden'));
		
		$data_pemakaian = [
			'no_barang' => $this->input->post('no_barang'),
			'tgl_diminta' => $this->input->post('tgl_diminta'),
			'tgl_diberikan' => $this->input->post('tgl_diberikan'),
			'nama' => $this->input->post('nama'),
			'alamat' => $this->input->post('alamat'),
			'gudang' => $this->input->post('gudang'),
			'kode_a' => $this->input->post('kode_a'),
			'kode_jurnal' => $this->input->post('kode_jurnal'),
			'banyak_jenis' => $this->input->post('banyak_jenis'),
			'no_pk' => $this->input->post('no_pk'),
			'no_pdf' => $this->input->post('no_pdf'),
			'no_ski' => $this->input->post('no_ski'),
			'no_pk_a' => $this->input->post('no_pk_a'),
			'kode_perkiraan' => $this->input->post('kode_perkiraan'),
		];

		$data_detail_pemakaian = [];

		for ($i=0; $i < $jumlah_barang_pemakaian ; $i++) { 
			array_push($data_detail_pemakaian, ['nama_barang' => $this->input->post('nama_barang_hidden')[$i]]);
			$data_detail_pemakaian[$i]['no_barang'] = $this->input->post('no_barang');
			$data_detail_pemakaian[$i]['tgl_diminta'] = $this->input->post('tgl_diminta');
			$data_detail_pemakaian[$i]['tgl_diberikan'] = $this->input->post('tgl_diberikan');
			$data_detail_pemakaian[$i]['nama'] = $this->input->post('nama');
			$data_detail_pemakaian[$i]['alamat'] = $this->input->post('alamat');
			$data_detail_pemakaian[$i]['gudang'] = $this->input->post('gudang');
			$data_detail_pemakaian[$i]['kode_a'] = $this->input->post('kode_a');
			$data_detail_pemakaian[$i]['kode_jurnal'] = $this->input->post('kode_jurnal');
			$data_detail_pemakaian[$i]['banyak_jenis'] = $this->input->post('banyak_jenis');
			$data_detail_pemakaian[$i]['no_pk'] = $this->input->post('no_pk');
			$data_detail_pemakaian[$i]['no_pdf'] = $this->input->post('no_pdf');
			$data_detail_pemakaian[$i]['no_ski'] = $this->input->post('no_ski');
			$data_detail_pemakaian[$i]['no_pk_a'] = $this->input->post('no_pk_a');
			$data_detail_pemakaian[$i]['kode_perkiraan'] = $this->input->post('kode_perkiraan');
			$data_detail_pemakaian[$i]['no_normalisasi'] = $this->input->post('no_normalisasi_hidden')[$i];
			$data_detail_pemakaian[$i]['satuan'] = $this->input->post('satuan_hidden')[$i];
			$data_detail_pemakaian[$i]['minta_a'] = $this->input->post('minta_a_hidden')[$i];
			$data_detail_pemakaian[$i]['minta_b'] = $this->input->post('minta_b_hidden')[$i];
			$data_detail_pemakaian[$i]['diterima_a'] = $this->input->post('diterima_a_hidden')[$i];
			$data_detail_pemakaian[$i]['diterima_b'] = $this->input->post('diterima_b_hidden')[$i];
			$data_detail_pemakaian[$i]['uang'] = $this->input->post('uang_hidden')[$i];

		}
			$this->m_fitur->tambah($data_pemakaian);
			$this->m_detail_fitur->tambah($data_detail_pemakaian);
			$this->session->set_flashdata('success', 'Invoice <strong>Pemakaian</strong> Berhasil Dibuat!');
			redirect('fitur/detail_pemakaian/'.$data_pemakaian['no_barang']);
		
	}
	public function hapus_pemakaian($no_pemakaian){
		if($this->m_fitur->hapus_pemakaian($no_pemakaian) && $this->m_detail_fitur->hapus_pemakaian($no_pemakaian)){
			$this->session->set_flashdata('success', 'Invoice Pemakaian <strong>Berhasil</strong> Dihapus!');
			redirect('fitur');
		} else {
			$this->session->set_flashdata('error', 'Invoice Pemakaian <strong>Gagal</strong> Dihapus!');
			redirect('fitur');
		}
	}
	public function keranjang_barang(){
		$this->load->view('fitur/keranjang_pemakaian');
	}
	//pengembalian
	public function lihat_pengembalian(){
		$this->data['title'] = 'Data Pengembalian';
		$this->data['all_pengembalian'] = $this->m_fitur->lihat_pengembalian();

		$this->load->view('fitur/lihat_pengembalian', $this->data);
	}
	
	public function detail_pengembalian($pengembalian){
		$this->data['title'] = 'Detail Pengembalian';
		$this->data['pengembalian'] = $this->m_fitur->lihat_no_pengembalian($pengembalian);
		$this->data['all_detail_pengembalian'] = $this->m_detail_fitur->lihat_no_pengembalian($pengembalian);
		$this->data['no'] = 1;

		$this->load->view('fitur/detail_pengembalian', $this->data);
	}
	public function tambah_pengembalian(){
		$this->data['title'] = 'Tambah Pengembalian';

		$this->load->view('fitur/tambah_pengembalian', $this->data);
	}
	public function proses_tambah_pengembalian(){
		$jumlah_barang_pengembalian = count($this->input->post('nama_barang_hidden'));
		
		$data_pengembalian = [
			'no_barang' => $this->input->post('no_barang'),
			'tgl_dikembalikan' => $this->input->post('tgl_dikembalikan'),
			'tgl_diterima' => $this->input->post('tgl_diterima'),
			'nama' => $this->input->post('nama'),
			'alamat' => $this->input->post('alamat'),
			'gudang' => $this->input->post('gudang'),
			'kode' => $this->input->post('kode'),
			'kode_jurnal' => $this->input->post('kode_jurnal'),
			'jenis' => $this->input->post('jenis'),
			'no_urut' => $this->input->post('no_urut'),
			'no_pk' => $this->input->post('no_pk'),
			'kode_perkiraan' => $this->input->post('kode_perkiraan'),
			'no_pk_a' => $this->input->post('no_pk_a'),
			'no_pdl' => $this->input->post('no_pdl'),
		];

		$data_detail_pengembalian = [];

		for ($i=0; $i < $jumlah_barang_pengembalian ; $i++) { 
			array_push($data_detail_pengembalian, ['nama_barang' => $this->input->post('nama_barang_hidden')[$i]]);
			$data_detail_pengembalian[$i]['no_barang'] = $this->input->post('no_barang');
			$data_detail_pengembalian[$i]['tgl_dikembalikan'] = $this->input->post('tgl_dikembalikan');
			$data_detail_pengembalian[$i]['tgl_diterima'] = $this->input->post('tgl_diterima');
			$data_detail_pengembalian[$i]['nama'] = $this->input->post('nama');
			$data_detail_pengembalian[$i]['alamat'] = $this->input->post('alamat');
			$data_detail_pengembalian[$i]['gudang'] = $this->input->post('gudang');
			$data_detail_pengembalian[$i]['kode'] = $this->input->post('kode');
			$data_detail_pengembalian[$i]['kode_jurnal'] = $this->input->post('kode_jurnal');
			$data_detail_pengembalian[$i]['jenis'] = $this->input->post('jenis');
			$data_detail_pengembalian[$i]['no_urut'] = $this->input->post('no_urut');
			$data_detail_pengembalian[$i]['no_pk'] = $this->input->post('no_pk');
			$data_detail_pengembalian[$i]['kode_perkiraan'] = $this->input->post('kode_perkiraan');
			$data_detail_pengembalian[$i]['no_pk_a'] = $this->input->post('no_pk_a');
			$data_detail_pengembalian[$i]['no_pdl'] = $this->input->post('no_pdl');
			$data_detail_pengembalian[$i]['no_normalisasi'] = $this->input->post('no_normalisasi_hidden')[$i];
			$data_detail_pengembalian[$i]['satuan'] = $this->input->post('satuan_hidden')[$i];
			$data_detail_pengembalian[$i]['kembali_a'] = $this->input->post('kembali_a_hidden')[$i];
			$data_detail_pengembalian[$i]['kembali_b'] = $this->input->post('kembali_b_hidden')[$i];
			$data_detail_pengembalian[$i]['diterima_a'] = $this->input->post('diterima_a_hidden')[$i];
			$data_detail_pengembalian[$i]['diterima_b'] = $this->input->post('diterima_b_hidden')[$i];
			$data_detail_pengembalian[$i]['kode_a'] = $this->input->post('kode_a_hidden')[$i];
			$data_detail_pengembalian[$i]['harga'] = $this->input->post('harga_hidden')[$i];
			$data_detail_pengembalian[$i]['uang'] = $this->input->post('uang_hidden')[$i];

		}
			$this->m_fitur->tambah_pengembalian($data_pengembalian);
			$this->m_detail_fitur->tambah_pengembalian($data_detail_pengembalian);
			$this->session->set_flashdata('success', 'Invoice <strong>Pengembalian</strong> Berhasil Dibuat!');
			redirect('fitur/detail_pengembalian/'.$data_pengembalian['no_barang']);
		
	}
	
	public function hapus_pengembalian($no_pengembalian){
		if($this->m_fitur->hapus_pengembalian($no_pengembalian) && $this->m_detail_fitur->hapus_pengembalian($no_pengembalian)){
			$this->session->set_flashdata('success', 'Invoice Pengembalian <strong>Berhasil</strong> Dihapus!');
			redirect('fitur/lihat_pengembalian');
		} else {
			$this->session->set_flashdata('error', 'Invoice Pengembalian <strong>Gagal</strong> Dihapus!');
			redirect('fitur/lihat_pengembalian');
		}
	}
	public function keranjang_pengembalian(){
		$this->load->view('fitur/keranjang_pengembalian');
	}
	//surat
	public function lihat_surat(){
		$this->data['title'] = 'Data Surat';
		$this->data['all_surat'] = $this->m_fitur->lihat_surat();

		$this->load->view('fitur/lihat_surat', $this->data);
	}
	public function tambah_surat(){
		$this->data['title'] = 'Tambah Pengembalian';

		$this->load->view('fitur/tambah_surat', $this->data);
	}
	public function proses_surat(){
		$jumlah_barang_surat = count($this->input->post('nama_barang_hidden'));
		
		$data_surat = [
			'no_barang' => $this->input->post('no_barang'),
			'nama' => $this->input->post('nama'),
			'alamat' => $this->input->post('alamat'),
			'kode' => $this->input->post('kode'),
			'tgl' => $this->input->post('tgl'),
			'tujuan' => $this->input->post('tujuan'),
			'nopol' => $this->input->post('nopol'),
			'nama_pengemudi' => $this->input->post('nama_pengemudi'),
		];

		$data_detail_surat = [];

		for ($i=0; $i < $jumlah_barang_surat ; $i++) { 
			array_push($data_detail_surat, ['nama_barang' => $this->input->post('nama_barang_hidden')[$i]]);
			$data_detail_surat[$i]['no_barang'] = $this->input->post('no_barang');
			$data_detail_surat[$i]['nama'] = $this->input->post('nama');
			$data_detail_surat[$i]['alamat'] = $this->input->post('alamat');
			$data_detail_surat[$i]['kode'] = $this->input->post('kode');
			$data_detail_surat[$i]['tgl'] = $this->input->post('tgl');
			$data_detail_surat[$i]['tujuan'] = $this->input->post('tujuan');
			$data_detail_surat[$i]['nopol'] = $this->input->post('nopol');
			$data_detail_surat[$i]['nama_pengemudi'] = $this->input->post('nama_pengemudi');
			$data_detail_surat[$i]['satuan'] = $this->input->post('satuan_hidden')[$i];
			$data_detail_surat[$i]['jumlah'] = $this->input->post('jumlah_hidden')[$i];
			$data_detail_surat[$i]['keterangan'] = $this->input->post('keterangan_hidden')[$i];
		}
			$this->m_fitur->tambah_surat($data_surat);
			$this->m_detail_fitur->tambah_surat($data_detail_surat);
			$this->session->set_flashdata('success', 'Invoice <strong>Surat</strong> Berhasil Dibuat!');
			redirect('fitur/detail_surat/'.$data_surat['no_barang']);
	}
	public function detail_surat($surat){
		$this->data['title'] = 'Detail Surat';
		$this->data['surat'] = $this->m_fitur->lihat_no_surat($surat);
		$this->data['all_detail_surat'] = $this->m_detail_fitur->lihat_no_surat($surat);
		$this->data['no'] = 1;

		$this->load->view('fitur/detail_surat', $this->data);
	}
	public function hapus_surat($surat){
		if($this->m_fitur->hapus_surat($surat) && $this->m_detail_fitur->hapus_surat($surat)){
			$this->session->set_flashdata('success', 'Invoice Surat <strong>Berhasil</strong> Dihapus!');
			redirect('fitur/lihat_surat');
		} else {
			$this->session->set_flashdata('error', 'Invoice Surat <strong>Gagal</strong> Dihapus!');
			redirect('fitur/lihat_surat');
		}
	}
	public function keranjang_surat(){
		$this->load->view('fitur/keranjang_surat');
	}
	public function get_all_barang(){
		$data = $this->m_barang->lihat_nama_barang($_POST['nama_barang']);
		echo json_encode($data);
	}

	public function export_pemakaian($no_penjualan){
		$dompdf = new Dompdf();
		$this->data['fitur'] = $this->m_fitur->lihat_no_pemakaian($no_penjualan);
		$this->data['all_detail_penjualan'] = $this->m_detail_fitur->lihat_no_pemakaian($no_penjualan);
		$this->data['title'] = 'Laporan Detail Pemakaian';
		$this->data['no'] = 1;

		$dompdf->setPaper('A4', 'Landscape');
		$html = $this->load->view('fitur/detail_report', $this->data, true);
		$dompdf->load_html($html);
		$dompdf->render();
		$dompdf->stream('Laporan Detail Pemakaian Tanggal ' . date('d F Y'), array("Attachment" => false));
	}
	public function export_pengembalian($no_penjualan){
		$dompdf = new Dompdf();
		$this->data['fitur'] = $this->m_fitur->lihat_no_pengembalian($no_penjualan);
		$this->data['all_detail_penjualan'] = $this->m_detail_fitur->lihat_no_pengembalian($no_penjualan);
		$this->data['title'] = 'Laporan Detail Pengembalian';
		$this->data['no'] = 1;

		$dompdf->setPaper('A4', 'Landscape');
		$html = $this->load->view('fitur/detail_report_pengembalian', $this->data, true);
		$dompdf->load_html($html);
		$dompdf->render();
		$dompdf->stream('Laporan Detail Pengembalian Tanggal ' . date('d F Y'), array("Attachment" => false));
	}
	public function export_surat($no_penjualan){
		$dompdf = new Dompdf();
		$this->data['fitur'] = $this->m_fitur->lihat_no_surat($no_penjualan);
		$this->data['all_detail_penjualan'] = $this->m_detail_fitur->lihat_no_surat($no_penjualan);
		$this->data['title'] = 'Laporan Detail Pengembalian';
		$this->data['no'] = 1;

		$dompdf->setPaper('A4', 'Portrait');
		$html = $this->load->view('fitur/detail_report_surat', $this->data, true);
		$dompdf->load_html($html);
		$dompdf->render();
		$dompdf->stream('Laporan Detail Pengembalian Tanggal ' . date('d F Y'), array("Attachment" => false));
	}
	public function excel()
		{
			
			$spreadsheet = new Spreadsheet();
			$sheet = $spreadsheet->setActiveSheetIndex(0);
			$sheet = $spreadsheet->getActiveSheet()->setTitle('Kode 7');
			$sheet->setCellValue('A1', 'No');
			$sheet->setCellValue('B1', 'Tanggal diminta');
			$sheet->setCellValue('C1', 'Tanggal diberikan');
			$sheet->setCellValue('D1', 'Nama');
			$sheet->setCellValue('E1', 'Alamat');
			$sheet->setCellValue('F1', 'Gudang');
			$sheet->setCellValue('G1', 'Kode');
			$sheet->setCellValue('H1', 'Kode jurnal');
			$sheet->setCellValue('I1', 'Nama barang');
			$sheet->setCellValue('J1', 'No normalisasi');
			$sheet->setCellValue('K1', 'Satuan');
			$sheet->setCellValue('L1', 'Diminta dengan angka');
			$sheet->setCellValue('M1', 'Diminta dengan huruf');
			$sheet->setCellValue('N1', 'Diterima dengan angka');
			$sheet->setCellValue('O1', 'Diterima dengan huruf');
			$sheet->setCellValue('P1', 'Jumlah uang');
			$sheet->setCellValue('Q1', 'Banyak jenis barang');
			$sheet->setCellValue('R1', 'No PK');
			$sheet->setCellValue('S1', 'No PDL');
			$sheet->setCellValue('T1', 'No urut SKI/SKP/PKP/PFK');
			$sheet->setCellValue('U1', 'No PK');
			$sheet->setCellValue('V1', 'Kode perkiraan');
			
			$siswa = $this->m_detail_fitur->ExportPemakaian();
			$no = 1;
			$x = 2;
			foreach($siswa as $row)
			{
				$sheet->setCellValue('A'.$x, $no++);
				$sheet->setCellValue('B'.$x, $row->tgl_diminta);
				$sheet->setCellValue('C'.$x, $row->tgl_diberikan);
				$sheet->setCellValue('D'.$x, $row->nama);
				$sheet->setCellValue('E'.$x, $row->alamat);
				$sheet->setCellValue('F'.$x, $row->gudang);
				$sheet->setCellValue('G'.$x, $row->kode_a);
				$sheet->setCellValue('H'.$x, $row->kode_jurnal);
				$sheet->setCellValue('I'.$x, $row->nama_barang);
				$sheet->setCellValue('J'.$x, $row->no_normalisasi);
				$sheet->setCellValue('K'.$x, $row->satuan);
				$sheet->setCellValue('L'.$x, $row->minta_a);
				$sheet->setCellValue('M'.$x, $row->minta_b);
				$sheet->setCellValue('N'.$x, $row->diterima_a);
				$sheet->setCellValue('O'.$x, $row->diterima_b);
				$sheet->setCellValue('P'.$x, $row->uang);
				$sheet->setCellValue('Q'.$x, $row->banyak_jenis);
				$sheet->setCellValue('R'.$x, $row->no_pk);
				$sheet->setCellValue('S'.$x, $row->no_pdf);
				$sheet->setCellValue('T'.$x, $row->no_ski);
				$sheet->setCellValue('U'.$x, $row->no_pk_a);
				$sheet->setCellValue('V'.$x, $row->kode_perkiraan);
				$x++;
			}
			$sheet = $spreadsheet->createSheet();
			$sheet = $spreadsheet->setActiveSheetIndex(1);
			$sheet = $spreadsheet->getActiveSheet()->setTitle('Kode 3');
			$sheet->setCellValue('A1', 'No');
			$sheet->setCellValue('B1', 'Tanggal dikembalikan');
			$sheet->setCellValue('C1', 'Tanggal diterima');
			$sheet->setCellValue('D1', 'Nama');
			$sheet->setCellValue('E1', 'Alamat');
			$sheet->setCellValue('F1', 'Gudang');
			$sheet->setCellValue('G1', 'Kode');
			$sheet->setCellValue('H1', 'Kode jurnal');
			$sheet->setCellValue('I1', 'Nama barang');
			$sheet->setCellValue('J1', 'No normalisasi');
			$sheet->setCellValue('K1', 'Satuan');
			$sheet->setCellValue('L1', 'DIkembalikan dengan angka');
			$sheet->setCellValue('M1', 'Dikembalikan dengan huruf');
			$sheet->setCellValue('N1', 'Diterima dengan angka');
			$sheet->setCellValue('O1', 'Diterima dengan huruf');
			$sheet->setCellValue('P1', 'Kode');
			$sheet->setCellValue('Q1', 'Harga satuan');
			$sheet->setCellValue('R1', 'Jumlah uang');
			$sheet->setCellValue('S1', 'Banyak jenis barang');
			$sheet->setCellValue('T1', 'No PK');
			$sheet->setCellValue('U1', 'No PDL');
			$sheet->setCellValue('V1', 'No urut SKI/SKP/PKP/PFK');
			$sheet->setCellValue('W1', 'No PK');
			$sheet->setCellValue('X1', 'Kode perkiraan');
			
			$siswa = $this->m_detail_fitur->ExportPengembalian();
			$no = 1;
			$x = 2;
			foreach($siswa as $row)
			{
				$sheet->setCellValue('A'.$x, $no++);
				$sheet->setCellValue('B'.$x, $row->tgl_dikembalikan);
				$sheet->setCellValue('C'.$x, $row->tgl_diterima);
				$sheet->setCellValue('D'.$x, $row->nama);
				$sheet->setCellValue('E'.$x, $row->alamat);
				$sheet->setCellValue('F'.$x, $row->gudang);
				$sheet->setCellValue('G'.$x, $row->kode);
				$sheet->setCellValue('H'.$x, $row->kode_jurnal);
				$sheet->setCellValue('I'.$x, $row->nama_barang);
				$sheet->setCellValue('J'.$x, $row->no_normalisasi);
				$sheet->setCellValue('K'.$x, $row->satuan);
				$sheet->setCellValue('L'.$x, $row->kembali_a);
				$sheet->setCellValue('M'.$x, $row->kembali_b);
				$sheet->setCellValue('N'.$x, $row->diterima_a);
				$sheet->setCellValue('O'.$x, $row->diterima_b);
				$sheet->setCellValue('P'.$x, $row->kode_a);
				$sheet->setCellValue('Q'.$x, $row->harga);
				$sheet->setCellValue('R'.$x, $row->uang);
				$sheet->setCellValue('S'.$x, $row->jenis);
				$sheet->setCellValue('T'.$x, $row->no_pk);
				$sheet->setCellValue('U'.$x, $row->no_pdl);
				$sheet->setCellValue('V'.$x, $row->no_urut);
				$sheet->setCellValue('W'.$x, $row->no_pk_a);
				$sheet->setCellValue('X'.$x, $row->kode_perkiraan);
				$x++;
			}
			$sheet = $spreadsheet->createSheet();
			$sheet = $spreadsheet->setActiveSheetIndex(2);
			$sheet = $spreadsheet->getActiveSheet()->setTitle('Surat jalan');
			$sheet->setCellValue('A1', 'No');
			$sheet->setCellValue('B1', 'Nama');
			$sheet->setCellValue('C1', 'Alamat');
			$sheet->setCellValue('D1', 'Kode');
			$sheet->setCellValue('E1', 'Tanggal');
			$sheet->setCellValue('F1', 'Tujuan');
			$sheet->setCellValue('G1', 'No polisi');
			$sheet->setCellValue('H1', 'Nama Pengemudi');
			$sheet->setCellValue('I1', 'Nama barang');
			$sheet->setCellValue('J1', 'Satuan');
			$sheet->setCellValue('K1', 'Jumlah');
			$sheet->setCellValue('L1', 'Keterangan');
			
			$siswa = $this->m_detail_fitur->ExportSurat();
			$no = 1;
			$x = 2;
			foreach($siswa as $row)
			{
				$sheet->setCellValue('A'.$x, $no++);
				$sheet->setCellValue('B'.$x, $row->nama);
				$sheet->setCellValue('C'.$x, $row->alamat);
				$sheet->setCellValue('D'.$x, $row->kode);
				$sheet->setCellValue('E'.$x, $row->tgl);
				$sheet->setCellValue('F'.$x, $row->tujuan);
				$sheet->setCellValue('G'.$x, $row->nopol);
				$sheet->setCellValue('H'.$x, $row->nama_pengemudi);
				$sheet->setCellValue('I'.$x, $row->nama_barang);
				$sheet->setCellValue('J'.$x, $row->satuan);
				$sheet->setCellValue('K'.$x, $row->jumlah);
				$sheet->setCellValue('L'.$x, $row->keterangan);
				$x++;
			}
			$writer = new Xlsx($spreadsheet);
			$filename = 'laporan';
			
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
			header('Cache-Control: max-age=0');
	
			$writer->save('php://output');
		}
	function get_autocomplete(){
        if (isset($_GET['term'])) {
            $result = $this->m_fitur->search_blog($_GET['term']);
            if (count($result) > 0) {
            foreach ($result as $row)
                $arr_result[] = $row->nama_barang;
                echo json_encode($arr_result);
            }
        }
    }
	
}